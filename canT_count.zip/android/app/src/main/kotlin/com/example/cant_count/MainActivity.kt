package com.example.cant_count

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
