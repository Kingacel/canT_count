from flask import Flask, request, jsonify
from ultralytics import YOLO
import os

app = Flask(__name__)

# Load your trained YOLOv8 model (put best.pt in same folder or give full path)
model = YOLO("best.pt")  # Replace with your actual trained model path

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route("/detect", methods=["POST"])
def detect():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    filename = file.filename or "uploaded.jpg"
    filepath = os.path.join(UPLOAD_DIR, filename)
    file.save(filepath)

    # Run detection on the uploaded image
    results = model(filepath)

    counts = {}
    total = 0

    # Mapping class names to coin values (update based on your model's classes)
    value_map = {
        "1_rupee": 1,
        "2_rupee": 2,
        "5_rupee": 5,
        "10_rupee": 10
    }

    # Extract detection info
    for result in results:
        boxes = result.boxes
        for cls_id in boxes.cls.cpu().numpy():
            cls_name = model.names[int(cls_id)]
            coin_value = value_map.get(cls_name, 0)
            counts[cls_name] = counts.get(cls_name, 0) + 1
            total += coin_value

    return jsonify({
        "counts": counts,
        "total": total,
        "num_detected": sum(counts.values())
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
