import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:network_info_plus/network_info_plus.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CoinCounterPage(),
    );
  }
}

class CoinCounterPage extends StatefulWidget {
  const CoinCounterPage({super.key});
  @override
  State<CoinCounterPage> createState() => _CoinCounterPageState();
}

class _CoinCounterPageState extends State<CoinCounterPage> {
  final ImagePicker _picker = ImagePicker();
  final NetworkInfo _networkInfo = NetworkInfo();

  String? _localIp;
  String _status = 'Idle';
  File? _image;
  Map<String, dynamic>? _result;

  @override
  void initState() {
    super.initState();
    _autoDetectLocalIp();
  }

  Future<void> _autoDetectLocalIp() async {
    if (kIsWeb) {
      setState(() => _status = 'Local IP detection not supported on Web');
      return;
    }

    try {
      final ip = await _networkInfo.getWifiIP();
      if (ip != null) {
        setState(() {
          _localIp = ip;
          _status = 'Local IP detected: $_localIp';
        });
      } else {
        setState(() => _status = 'Could not detect local IP (not on Wi-Fi?)');
      }
    } catch (e) {
      setState(() => _status = 'Error detecting IP: $e');
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(source: source, imageQuality: 80);
      if (picked == null) return;
      setState(() {
        _image = File(picked.path);
        _result = null;
        _status = 'Image picked, ready to upload';
      });
      await _uploadImage(File(picked.path));
    } catch (e) {
      setState(() => _status = 'Image pick error: $e');
    }
  }

  Future<void> _uploadImage(File image) async {
    if (_localIp == null) {
      setState(() => _status = 'No local IP detected. Trying again...');
      await _autoDetectLocalIp();
      if (_localIp == null) {
        setState(() => _status = 'No IP detected. Cannot upload.');
        return;
      }
    }

    final uri = Uri.parse('http://$_localIp:5000/detect');
    setState(() => _status = 'Uploading image to $uri ...');

    try {
      var request = http.MultipartRequest('POST', uri);
      request.files.add(await http.MultipartFile.fromPath('file', image.path));

      var streamedResponse =
          await request.send().timeout(const Duration(seconds: 20));
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        setState(() {
          _result = data;
          _status = 'Upload successful';
        });
      } else {
        setState(() => _status = 'Server error: ${response.statusCode}');
      }
    } on SocketException catch (e) {
      setState(() =>
          _status = 'Socket error: $e — Is server running & on same Wi-Fi?');
    } on Exception catch (e) {
      setState(() => _status = 'Upload failed: $e');
    }
  }

  Widget _resultWidget() {
    if (_result == null) return Text(_status);

    final counts = _result!['counts'] ?? {};
    final total = _result!['total'] ?? _result!['message'] ?? '';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Server response: ${jsonEncode(_result)}'),
        const SizedBox(height: 8),
        if (counts is Map)
          ...counts.entries.map((e) => Text('₹${e.key} x ${e.value}')),
        if (total is int || total is String)
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Text('Total: ₹$total',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmartCoin Counter'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            if (_image != null)
              Image.file(_image!, height: 240, fit: BoxFit.cover)
            else
              const SizedBox(
                  height: 240, child: Center(child: Text('No image selected'))),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: () => _pickImage(ImageSource.camera),
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Camera'),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () => _pickImage(ImageSource.gallery),
                  icon: const Icon(Icons.photo),
                  label: const Text('Gallery'),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Text('Local IP: ${_localIp ?? "Detecting..."}'),
            const SizedBox(height: 8),
            Expanded(child: SingleChildScrollView(child: _resultWidget())),
          ],
        ),
      ),
    );
  }
}
